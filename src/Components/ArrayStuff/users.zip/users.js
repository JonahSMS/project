export default [
    {
    name: "Sam Smith",
    occupation: "songer",
    password: "Samsamity"
  },
  {
    name: "Jared Squared",
    occupation: "Math",
    password: "MathisBlind28"
  },
  {
    name: "Boaz Sze",
    occupation: "party boy",
    password: "BigDick69"
  },
  {
    name: "Austin Texas",
    occupation: "Prof",
    password: "DnDLord69"
  },
  {
    name: "Patricia Santos",
    occupation: "Btchh",
    password: "tanginamoka"
  },
  {
    name: "Austin Texas",
    occupation: "Prof",
    password: "DnDLord69"
  },
  {
    name: "Johan Man",
    occupation: "Bot Master",
    password: "1v1mebutineedbots"
  },
]